#-*- coding:utf-8 -*-


'''
@Time  : 2020/12/14 17:23
@Author: ZhangQiang
'''



def sum_two_num(a,b):
    return a+b